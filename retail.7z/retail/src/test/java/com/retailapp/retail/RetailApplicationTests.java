package com.retailapp.retail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailApplicationTests {

	@Test
	void contextLoads() {
	}

}
